
public class myThirdPersonController : ThirdPersonController
{
    // The actual controller is in ThirdPersonController. 
    // For the PUN package, we just inherit that.

    // This class replaces the JS version of the same name for this tutorial.
    
    // Actually, the ThirdPersonController works (more or less) the same way as it's JS counterpart,
    // but it's much easier to integrate being in C# as well (no need to move files around).
    
    // Please bear with us for this little fake.
}
