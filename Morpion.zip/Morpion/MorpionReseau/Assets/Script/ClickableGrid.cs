﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ClickableGrid : MonoBehaviour {

    private Morpion morpionManager;
    private Button selfB;
    private Image selfI;
    private char[] num;
    public Sprite J1, J2;
    private PhotonView view;

    private void Awake()
    {
        selfB = GetComponent<Button>();
        selfI = transform.GetChild(0).GetComponent<Image>();
        morpionManager = transform.parent.GetComponent<Morpion>();
        num = name.ToCharArray(1, 2);
        selfB.onClick.AddListener(delegate { Click(); });
        view = GetComponent<PhotonView>();
    }

    private void Click() //envoit les coordonnées de la case au morpion (verification de la partie et coloration de la case)
    {
        if (PhotonNetwork.player.ID == morpionManager.GetCurrentId && !morpionManager.EndGame) {
            int x, y;
            x = (int)char.GetNumericValue(num[0]);
            y = (int)char.GetNumericValue(num[1]);
            bool player = morpionManager.CallBackMorpion(x, y);
            view.RPC("CallAfterClick", PhotonTargets.All, player);
        }
    }

    [PunRPC]
    private void CallAfterClick(bool player)
    {
        if (player)
        {
            selfI.sprite = J1;
        }
        else
        {
            selfI.sprite = J2;
        }
        selfB.enabled = false;
    }
}
