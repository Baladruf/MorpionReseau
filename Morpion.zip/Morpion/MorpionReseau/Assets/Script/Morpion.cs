﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Morpion : Photon.MonoBehaviour {

    private int[,] caseMorpion;
    private Image[,] CaseImage;

    private PlayerAttribut[] playerAttribut;

    public Text result;
    private bool endGame = false;

    private int tour = 1;

    public Sprite etoile, rond;
    public Text TJ1, TJ2;
    public Button back;

    private PhotonView view;

    private bool inDisconnect = false;

    public int GetCurrentId { get { return playerAttribut[0].id; } }

    public bool EndGame { get { return endGame; } }

    private void Awake()
    {
        back.onClick.AddListener(delegate { PhotonNetwork.Disconnect(); });
        view = GetComponent<PhotonView>();
        caseMorpion = new int[3, 3];
        CaseImage = new Image[3, 3];
        int rangImage = 1;
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 3; j++)
            {
                caseMorpion[i, j] = 0;
                CaseImage[i, j] = transform.GetChild(rangImage).GetChild(0).GetComponent<Image>();
                rangImage++;
            }
        }
        playerAttribut = new PlayerAttribut[2];
    }

    private void OnEnable() // le master client attribut l'ordre des joueurs de façon aleatoir
    {
        Debug.Log(PhotonNetwork.player.ID);
        if (PhotonNetwork.isMasterClient)
        {
            int alea = Random.Range(1, 100) <= 50 ? 0 : 1;
            playerAttribut[alea] = new PlayerAttribut(PhotonNetwork.playerList[0].ID, PhotonNetwork.playerList[0].NickName);
            playerAttribut[1 - alea] = new PlayerAttribut(PhotonNetwork.playerList[1].ID, PhotonNetwork.playerList[1].NickName);
            view.RPC("SendStart", PhotonTargets.All, playerAttribut[0].id, playerAttribut[1].id, playerAttribut[0].name, playerAttribut[1].name);
        }
    }

    private void Update()
    {
        if (!endGame && !inDisconnect && PhotonNetwork.room != null && PhotonNetwork.room.PlayerCount != 2)
        {
            inDisconnect = true;
            RageQuit();
            //PhotonNetwork.Disconnect();
        }
    }

    [PunRPC]
    private void SendStart(int idP1, int idP2, string nameP1, string nameP2) //envoit l'ordre des tours à l'autre joueur
    {
        playerAttribut[0] = new PlayerAttribut(idP1, nameP1);
        playerAttribut[1] = new PlayerAttribut(idP2, nameP2);
        TJ1.text = playerAttribut[0].name;
        TJ2.text = playerAttribut[1].name;
    }

    [PunRPC]
    public bool CallBackMorpion(int x, int y) // appeler lors d'un clique d'une case, calcule l'avancer de la partie et renvoit le joueur pour colorier la case
    {
        bool j = tour == 1 ? true : false;
        view.RPC("LookRule", PhotonTargets.All, x, y);
        return j;
    }

    [PunRPC]
    private void LookRule(int x, int y) // calcule l'avancer de la partie
    {
        if (!endGame) {
            caseMorpion[x, y] = tour;
            int equal = 0;
            int oblique = 0, obliqueI = 0;
            for (int i = 0; i < 3; i++)
            {
                int vert = 0, hori = 0;
                for (int j = 0; j < 3; j++)
                {
                    if(caseMorpion[i, j] != 0)
                    {
                        equal++;
                    }
                    hori += caseMorpion[i, j];
                    vert += caseMorpion[j, i];
                    if (i == j)
                    {
                        oblique += caseMorpion[i, j];
                    }
                    if (i + j == 2)
                    {
                        obliqueI += caseMorpion[i, j];
                    }
                }
                if (hori % 3 == 0 && hori != 0)
                {
                    CaseImage[0, i].color = Color.red; CaseImage[1, i].color = Color.red; CaseImage[2, i].color = Color.red;
                    Win(hori > 0 ? true : false);
                    return;
                }
                else if (vert % 3 == 0 && vert != 0)
                {
                    CaseImage[i, 0].color = Color.red; CaseImage[i, 1].color = Color.red; CaseImage[i, 2].color = Color.red;
                    Win(vert > 0 ? true : false);
                    return;
                }
            }
            if (oblique % 3 == 0 && oblique != 0)
            {
                CaseImage[0, 0].color = Color.red; CaseImage[1, 1].color = Color.red; CaseImage[2, 2].color = Color.red;
                Win(oblique > 0 ? true : false);
                return;
            }
            else if (obliqueI % 3 == 0 && obliqueI != 0)
            {
                CaseImage[0, 2].color = Color.red; CaseImage[1, 1].color = Color.red; CaseImage[2, 0].color = Color.red;
                Win(obliqueI > 0 ? true : false);
                return;
            }
            if(equal == 9)
            {
                Equality();
                return;
            }
            Swap();
        }
    }

    [PunRPC]
    private void Win(bool j)
    {
        result.text = "le joueur " + playerAttribut[0].name + " a gagné !";
        endGame = true;
        back.gameObject.SetActive(true);
    }

    [PunRPC]
    private void Swap()
    {
        var save = playerAttribut[0];
        playerAttribut[0] = playerAttribut[1];
        playerAttribut[1] = save;
        Debug.Log(playerAttribut[0].name);
        tour *= -1;
    }

    private void RageQuit()
    {
        result.text = "Victoire par ragequit !";
        endGame = true;
        back.gameObject.SetActive(true);
    }

    private void Equality()
    {
        result.text = "Egalité !";
        endGame = true;
        back.gameObject.SetActive(true);
    }

    private class PlayerAttribut
    {
        public int id;
        public string name;

        public PlayerAttribut(int p_id, string p_name)
        {
            id = p_id;
            name = p_name;
        }
    }
}
