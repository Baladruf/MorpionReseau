﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using UnityEngine.SceneManagement;

public class TestCube : Photon.MonoBehaviour {

    private MeshRenderer renderer;

    
    private List<PlayerAttribut> idPlayers;

    private Color[] colors;
    private bool inDisconnect = false;

	// Use this for initialization
	void Awake () {
        renderer = GetComponent<MeshRenderer>();
        colors = new Color[3];
        colors[0] = Color.red;
        colors[1] = Color.yellow;
        colors[2] = Color.blue;
	}

    private void OnEnable()
    {
        idPlayers = new List<PlayerAttribut>(PhotonNetwork.room.PlayerCount);
        for (int i = 0; i < PhotonNetwork.playerList.Length; i++)// PhotonPlayer id in PhotonNetwork.playerList)
        {
            idPlayers.Add(new PlayerAttribut(PhotonNetwork.playerList[i].ID));
            idPlayers[i].playerColor = i;
        }
        if (PhotonNetwork.isMasterClient)
        {
            idPlayers.Shuffle();

            var memo = new MemoryStream();
            var bf = new BinaryFormatter();
            bf.Serialize(memo, idPlayers);

            var cript = Convert.ToBase64String(memo.GetBuffer());
            PhotonNetwork.RPC(this.photonView, "sendAlea", PhotonTargets.All, false, cript);
        }
        
        //Debug.Log(idPlayers[0].playerId);
    }

    [PunRPC]
    public void CallBackClick(int idPlayer, string idBlock)
    {
        if (idPlayers[0].playerId == idPlayer)
        {
            for(int i = 0; i < idPlayers.Count; i++)
            {
                if(idPlayers[i].playerId == idPlayer)
                {
                    renderer.material.color = colors[idPlayers[i].playerColor];
                    break;
                }
            }
            NextPlayer();
        }
    }

    private void NextPlayer()
    {
        PlayerAttribut saveId = idPlayers[0];
        for (int i = 0; i < idPlayers.Count - 1; i++)
        {
            idPlayers[i] = idPlayers[i + 1];
        }
        idPlayers[idPlayers.Count - 1] = saveId;
    }

    // Update is called once per frame
    void Update () {
        if (!inDisconnect && PhotonNetwork.room.PlayerCount < idPlayers.Count)
        {
            inDisconnect = true;
            PhotonNetwork.Disconnect();
        }
    }

    private void OnMouseDown()
    {
        //CallBackClick(PhotonNetwork.player.ID, "");
        PhotonNetwork.RPC(this.photonView, "CallBackClick", PhotonTargets.All, false, PhotonNetwork.player.ID, "");
        //Debug.Log(PhotonNetwork.player.ID);
    }

    [PunRPC]
    private void sendAlea(string att)
    {
        var memo = new MemoryStream(Convert.FromBase64String(att));
        var bf = new BinaryFormatter();
        idPlayers = (List<PlayerAttribut>)bf.Deserialize(memo);
    }

    [Serializable]
    public class PlayerAttribut
    {
        public int playerId;
        public int playerColor;

        public PlayerAttribut(int id)
        {
            playerId = id;
        }
    }
}
