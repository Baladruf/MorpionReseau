﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon;
using ExitGames.Client.Photon;

public class Player : PhotonPlayer {





    

    



    public Player(bool isLocal, int actorID, string name) : base(isLocal, actorID, name)
    {

    }

    protected internal Player(bool isLocal, int actorID, ExitGames.Client.Photon.Hashtable properties) : base(isLocal, actorID, properties)
    {
    }

    public override bool Equals(object p)
    {
        return base.Equals(p);
    }

    public override int GetHashCode()
    {
        return base.GetHashCode();
    }

    public override string ToString()
    {
        return base.ToString();
    }
}
