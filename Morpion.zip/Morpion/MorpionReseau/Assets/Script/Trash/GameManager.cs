﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.SceneManagement;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine.UI;

public class GameManager : Photon.MonoBehaviour {

    public GameObject menuP;

    public float speedRotate = 5;
    private List<PlayerAttribut> idPlayers;
    private List<GameObject> morpionCase;
    public Color[] colors;
    private int[,,] morpionCount;
    private bool isWin = false;
    private bool inDisconnect = false;

    public Text winText;
    public Button backMenu, Quit;

    private bool flagO, flagOI, flagO2, flagOI2;
    

    private void Awake()
    {
        backMenu.onClick.AddListener(delegate { PhotonNetwork.Disconnect(); });
        Quit.onClick.AddListener(delegate { Application.Quit(); });

        morpionCount = new int[3, 3, 3];
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                for (int k = 0; k < 3; k++)
                    morpionCount[i, j, k] = -1;
        morpionCase = new List<GameObject>();
        for(int i = 0; i < transform.childCount; i++)
        {
            morpionCase.Add(transform.GetChild(i).gameObject);
        }
    }

    private void OnEnable()
    {
        if (PhotonNetwork.isMasterClient)
        {
            idPlayers = new List<PlayerAttribut>(PhotonNetwork.room.PlayerCount);
            for (int i = 0; i < PhotonNetwork.playerList.Length; i++)// PhotonPlayer id in PhotonNetwork.playerList)
            {
                idPlayers.Add(new PlayerAttribut(PhotonNetwork.playerList[i].ID, PhotonNetwork.playerList[i].NickName));
                idPlayers[i].playerColor = i;
            }
        
            idPlayers.Shuffle();

            var memo = new MemoryStream();
            var bf = new BinaryFormatter();
            bf.Serialize(memo, idPlayers);

            var cript = Convert.ToBase64String(memo.GetBuffer());
            PhotonNetwork.RPC(this.photonView, "sendAlea", PhotonTargets.All, false, cript);
        }
    }

    // Update is called once per frame
    void Update () {
		if(!inDisconnect && PhotonNetwork.room != null && idPlayers != null && PhotonNetwork.room.PlayerCount < idPlayers.Count)
        {
            inDisconnect = true;
            PhotonNetwork.Disconnect();
        }
        /*if (photonView.isMine)
        {
            float axis = 0;
            if ((axis = Input.GetAxisRaw("Horizontal")) != 0)
            {
                transform.Rotate(0, axis * Time.deltaTime * speedRotate, 0);
            }
            if ((axis = Input.GetAxisRaw("Vertical")) != 0)
            {
                transform.Rotate(axis * Time.deltaTime * speedRotate, 0, 0);
            }
        }*/
	}

    [PunRPC]
    private void CallBackClick(int idPlayer, string idBlock)
    {
        if(idPlayers[0].playerId == idPlayer)
        {
            for(int i = 0; i < morpionCase.Count; i++)
            {
                if(morpionCase[i].name == idBlock/* && morpionCase[i].GetComponent<Material>().color != Color.white*/)
                {
                    morpionCase[i].GetComponent<MeshRenderer>().material.color = colors[idPlayers[0].playerColor];
                    morpionCase[i].GetComponent<Collider>().enabled = false;
                    var numTab = morpionCase[i].name.ToCharArray();
                    morpionCount[(int)char.GetNumericValue(numTab[1]), (int)char.GetNumericValue(numTab[2]), (int)char.GetNumericValue(numTab[3])] = idPlayer;
                    break;
                }
            }
            //LookGame(idPlayers[0].playerName);
            NextPlayer();
        }
    }

    /*public void ClickElement(int idPlayer, string idBlock)
    {
        PhotonNetwork.RPC(this.photonView, "CallBackClick", PhotonTargets.All, false, idPlayer, idBlock);
    }

    [PunRPC]
    private void LookGame(string name)
    {
        for(int z = 0; z < 3; z++)
        {
            flagO = true; flagOI = true;
            flagO2 = true; flagOI2 = true;

            for (int x = 0; x < 3; x++)
            {
                if (LookGameRule(x, z, morpionCount[0, 0, z], morpionCount[0, 2, z], true, name))
                    return;
                if (LookGameRule(z, x, morpionCount[z, 0, 0], morpionCount[z, 2, 0], false, name))
                    return;
            }
            if (flagO || flagOI || flagO2 || flagOI2)
            {
                Debug.Log("Win flag oblique");
                Win(name);
                return;
            }
        }
    }

    [PunRPC]
    private bool LookGameRule(int fAtt, int sAtt, int valO, int valOI, bool flagOther, string name)
    {
        bool flagH = true, flagV = true;
        for(int y = 0; y < 3; y++)
        {
            if(morpionCount[fAtt, y, sAtt] != morpionCount[fAtt, 0, sAtt] || morpionCount[fAtt, y, sAtt] == -1)
            {
                flagH = false;
            }
            if(morpionCount[y, fAtt, sAtt] != morpionCount[y, 0, sAtt] || morpionCount[y, fAtt, sAtt] == -1)
            {
                flagV = false;
            }

            if (flagOther)
            {
                if (fAtt == y && morpionCount[fAtt, y, sAtt] != valO || morpionCount[fAtt, y, sAtt] == -1)
                {
                    flagO = false;
                }
                if (fAtt + y == 2 && morpionCount[fAtt, y, sAtt] != valOI || morpionCount[fAtt, y, sAtt] == -1)
                {
                    flagOI = false;
                }
            }
            else
            {
                if (fAtt == y && morpionCount[fAtt, y, sAtt] != valO || morpionCount[fAtt, y, sAtt] == -1)
                {
                    flagO2 = false;
                }
                if (fAtt + y == 2 && morpionCount[fAtt, y, sAtt] != valOI || morpionCount[fAtt, y, sAtt] == -1)
                {
                    flagOI2 = false;
                }
            }
            
        }
        if(flagH || flagV)
        {
            Debug.Log("Win flag hori/vert");
            Win(name);
            return true;
        }
        return false;
    }*/

    [PunRPC]
    private void Win(string name)
    {
        Debug.Log("Win");
        isWin = true;
        winText.text = name + " remporte la partie";
        menuP.SetActive(true);
    }

    [PunRPC]
    private void NextPlayer()
    {
        PlayerAttribut saveId = idPlayers[0];
        for(int i = 0; i < idPlayers.Count -1; i++)
        {
            idPlayers[i] = idPlayers[i + 1];
        }
        idPlayers[idPlayers.Count - 1] = saveId;
    }

    [PunRPC]
    private void sendAlea(string att)
    {
        var memo = new MemoryStream(Convert.FromBase64String(att));
        var bf = new BinaryFormatter();
        idPlayers = (List<PlayerAttribut>)bf.Deserialize(memo);
    }

    public class PlayerAttribut
    {
        public int playerId;
        public string playerName;
        public int playerColor;

        public PlayerAttribut(int id, string name)
        {
            playerId = id;
            playerName = name;
        }
    }
}

public static class Utility
{
    private static System.Random rng = new System.Random();

    public static void Shuffle<T>(this IList<T> list)
    {
        int n = list.Count;
        while (n > 1)
        {
            n--;
            int k = rng.Next(n + 1);
            T value = list[k];
            list[k] = list[n];
            list[n] = value;
        }
    }
}
