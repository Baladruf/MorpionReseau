﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ClickElement : MonoBehaviour {

    private GameManager manager;
    private Image self;

	private void Awake()
    {
        manager = transform.parent.GetComponent<GameManager>();
        self = GetComponent<Image>();
        
    }

    private void OnMouseDown()
    {
        //manager.ClickElement(PhotonNetwork.player.ID, gameObject.name);
    }
}
