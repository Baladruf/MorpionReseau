﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon;
using UnityEngine.SceneManagement;

public class NetworkManager : PunBehaviour {

    private const string roomName = "RoomName";
    private RoomInfo[] roomList;

    //lier au menu principal
    public GameObject menuMain;
    public Dropdown dropdown;
    public Text stateText, statusCo;
    public InputField InputFieldPseudo;

    private bool isMaster = false, isJoin = false;

    //lier au room master
    public Text RMTextInfo, RMTextJoueur;
    public Button RMGo;

    //lier au join player
    public GameObject CreateMenu, JoinMenu;
    public Text JInfo, JJoueur;

    //Game
    public GameObject game;
    private bool startG = false;

    // Use this for initialization
    void Start () { //connection au serveur
        PhotonNetwork.autoJoinLobby = true;
        PhotonNetwork.ConnectUsingSettings("1.0");
        dropdown.ClearOptions();
        RMGo.onClick.AddListener(delegate {
            startG = true;
            PhotonNetwork.RPC(this.photonView, "GameStart", PhotonTargets.All, false);
        });
	}

    private void Update()
    {
        statusCo.text = "status : " + PhotonNetwork.connectionStateDetailed;
        if (isMaster && PhotonNetwork.room != null)
        {
            if (isMaster) { // le joueur ayant créer la salle peut lancer la partie si un autre joueur a rejoint sa salle
                if (PhotonNetwork.room.PlayerCount >= 2 && !RMGo.interactable)
                {
                    RMGo.interactable = true;
                }
                else if (PhotonNetwork.room.PlayerCount == 1 && RMGo.interactable)
                {
                    RMGo.interactable = false;
                }
            }
            RMTextJoueur.text = "";
            foreach(PhotonPlayer j in PhotonNetwork.playerList)
                RMTextJoueur.text += j.NickName +"\n";
        }else if(isJoin && PhotonNetwork.room != null) //le joueur ayant rejoint la salle peut voir le pseudo des autres joueurs
        {
            JJoueur.text = "";
            foreach (PhotonPlayer j in PhotonNetwork.playerList)
                JJoueur.text += j.NickName + "\n";
        }
    }

    public override void OnConnectedToMaster()
    {
        base.OnConnectedToMaster();
    }

    public override void OnJoinedLobby()
    {
        base.OnJoinedLobby();
    }

    public void CreateRoom() //option permettant au joueur de creer la salle
    {
        if (!PhotonNetwork.connected)
        {
            Debug.Log("no connected : "+PhotonNetwork.connectionStateDetailed.ToString());
        }else if(InputFieldPseudo.text == "")
        {
            stateText.text = "choisissez un pseudo";
        }
        else
        {
            RoomOptions options = new RoomOptions();
            options.MaxPlayers = 2;
            options.IsVisible = true;
            options.IsOpen = true;

            Debug.Log("create !!!");
            PhotonNetwork.CreateRoom(InputFieldPseudo.text + roomName + Guid.NewGuid().ToString("N"), options, TypedLobby.Default);
        }
    }

    public void JoinRoom() //option permettant au joueur de rejoindre une salle qu'il a choisit si elle n'est pas pleine
    {
        if (!PhotonNetwork.connected)
        {
            Debug.Log("join non connect");
            Debug.Log(PhotonNetwork.connectionStateDetailed.ToString());
        }
        else
        {
            if(roomList != null && InputFieldPseudo.text != "")
            {
                Debug.Log("state room = "+roomList[dropdown.value].ToString());
                PhotonNetwork.JoinRoom(roomList[dropdown.value].Name);
            }
            else
            {
                Debug.Log("room null");
                stateText.text = "choisissez un pseudo";
            }
        }
        /*else
        {
            Debug.Log("room deconne");
        }*/
    }

    public void Refresh() // refresh la liste des salles
    {
        roomList = PhotonNetwork.GetRoomList();
        Debug.Log("nb room = "+roomList.Length);
        Debug.Log("n2 : nb room = " + PhotonNetwork.countOfRooms);
        var list = new List<string>();
        for(int i = 0; roomList != null && i < roomList.Length; i++)
        {
            list.Add(roomList[i].Name.Split(new string[] { roomName}, StringSplitOptions.None)[0]);
        }
        dropdown.ClearOptions();
        dropdown.AddOptions(list);
    }

    public override void OnJoinedRoom()
    {
        base.OnJoinedRoom();
        stateText.text = "Join";
        PhotonNetwork.playerName = InputFieldPseudo.text;
        if (!isMaster)
        {
            isJoin = true;
            menuMain.SetActive(false);
            JoinMenu.SetActive(true);
        }
    }

    public override void OnPhotonJoinRoomFailed(object[] codeAndMsg)
    {
        base.OnPhotonJoinRoomFailed(codeAndMsg);
        stateText.text = "failed join : " + codeAndMsg.ToStringFull();
    }

    public override void OnCreatedRoom()
    {
        base.OnCreatedRoom();
        Debug.Log("create room");
        stateText.text = "create room";
        isMaster = true;
        menuMain.SetActive(false);
        CreateMenu.SetActive(true);
    }

    [PunRPC]
    private void GameStart()
    {
        startG = true;
        CreateMenu.SetActive(false);
        JoinMenu.SetActive(false);
        game.SetActive(true);
    }

    public override void OnDisconnectedFromPhoton()
    {
        base.OnDisconnectedFromPhoton();
        Debug.Log("disconnect");
        SceneManager.LoadScene("Main");
    }

    public void Quit()
    {
        Application.Quit();
    }
    /*public override void OnLeftRoom() // a voir plus tard
    {
        Debug.Log("left");
        if (PhotonNetwork.player.IsMasterClient)
        {
            foreach (PhotonPlayer p in PhotonNetwork.playerList)
                if (!p.IsMasterClient)
                    PhotonNetwork.CloseConnection(p);
        }
        base.OnLeftRoom();
        SceneManager.LoadScene("Main");
        Debug.Log("end left");
    }*/
}
